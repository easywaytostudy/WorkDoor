from django.db import models
from django.contrib.auth.models import User


# Create your models here.

class RangeAllocation(models.Model):

	# __tablename__ = 'range_allocations'
	id = models.AutoField(primary_key=True)
	start_date = models.FloatField(null=False)
	end_date = models.FloatField(null=False)
	hours = models.FloatField(null=False)
	organisation_id = models.IntegerField(null=False)
	organisation = models.CharField(max_length=100, null=False, help_text="'Organisation', foreign_keys=[organisation_id]")
	project_id = models.IntegerField(null=False, help_text="ForeignKey('projects.id'), null=False")
	project = models.CharField(max_length=100, null=True, help_text='Project')
	project_phase_id = models.IntegerField(null=False, help_text="ForeignKey('project_phases.id'), null=False")
	project_phase = models.CharField(max_length=100, null=True, help_text='ProjectPhase')
	staff_member_id = models.IntegerField(null=False, help_text="ForeignKey('staff_members.id'), null=True")
	staff_member = models.CharField(max_length=100, null=True, help_text='StaffMember')
	staff_role_id = models.IntegerField(null=False, help_text="ForeignKey('staff_roles.id'), null=True")
	staff_role = models.CharField(max_length=100, null=True, help_text="StaffRole")

	def __unicode__(self):
		return self.start_date

	class Meta:
		db_table = "range_allocations"
		verbose_name = "range allocations"



class Project(models.Model):
	# __tablename__ = 'projects'
	id = models.AutoField(primary_key=True)
	business_category_id = models.IntegerField(null =False, help_text=" ForeignKey('organisation_business_categories.id'), nullable=False")
	business_category = models.CharField(max_length=100, null=False, help_text= "OrganisationBusinessCategory")
	status = models.TextField(max_length=100,null=False)

	def __unicode__(self):
		return self.business_category

	class Meta:
		db_table = "project"
		verbose_name = "project"

