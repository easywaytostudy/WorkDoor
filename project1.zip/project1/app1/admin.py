from django.contrib import admin
from .models import RangeAllocation, Project

# Register your models here.
admin.site.register(RangeAllocation)
admin.site.register(Project)